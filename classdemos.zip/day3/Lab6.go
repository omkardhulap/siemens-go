package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"
)

type mystruct struct {
	Data struct {
		ID        int    `json:"id"`
		Email     string `json:"email"`
		FirstName string `json:"first_name"`
		LastName  string `json:"last_name"`
		Avatar    string `json:"avatar"`
	} `json:"data"`
	Ad struct {
		Company string `json:"company"`
		URL     string `json:"url"`
		Text    string `json:"text"`
	} `json:"ad"`
}

func main() {
	// ask user number
	var userno = 1
	fmt.Println("Enter user number : ")
	fmt.Scanf("%d", &userno)
	url := "https://reqres.in/api/users/" + strconv.Itoa(userno)
	resp, err := http.Get(url)
	defer resp.Body.Close()
	if err != nil {
		fmt.Println("Error handling Code for Get")
	} else {
		body, _ := ioutil.ReadAll(resp.Body)
		fmt.Println("body ", string(body))
		res := mystruct{}
		json.Unmarshal(body, &res)
		fmt.Println("res  - ", res.Data)
		fmt.Println("res  - ", res.Data.FirstName)

		//	json.Unmarshal([]byte(str), &res)

	}

}
