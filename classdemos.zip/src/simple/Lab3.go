package simple

func Add1(x int, y int) int {
	return x + y
}
func Add2(x, y int) int {
	return x + y
}
