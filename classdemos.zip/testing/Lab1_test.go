package main

import (
	"fmt"
	"testing"
)

func TestAdd(t *testing.T) {
	x := add(10, 30)

	if x != 40 {
		t.Error("Invalid Sum")
	}
}
func TestDivide(t *testing.T) {
	defer func() {
		if r := recover(); r != nil {
			t.Error("Invalid Divide - check second argument")
			fmt.Printf("Panic: %+v\n", r)
		}
	}()
	x := divide("10x", "20x")
	fmt.Println(" in Test Divide after call ", x)
	if x != 5 {
		t.Error("Invalid Divide")
	}

}
func BenchmarkAdd(b *testing.B) {
	for i := 0; i < b.N; i++ {
		_ = add(i*10, i*30)
	}
}
