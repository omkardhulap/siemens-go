package main

func add(i int, j int) int {
	return i + j
}

/*
func main() {
	x := add(20, 30)
	fmt.Println("x = ", x)
	fmt.Println("div = ", divide("10", "5"))
}
*/
