package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/dynamodb"
	"github.com/aws/aws-sdk-go/service/dynamodb/dynamodbattribute"
)

// List/Retrieve

//Create / Insert

func getdynamodb() *dynamodb.DynamoDB {
	sess, err := session.NewSession(&aws.Config{
		Region: aws.String("us-east-1")})

	if err != nil {
		fmt.Println("In err", err)
		panic("Problem in getting connection to AWS")
	} else {
		fmt.Println("Session Created Successfully")
		fmt.Println(sess)
		return dynamodb.New(sess)
	}

}

func Save(emp EmpStruct) {
	svc := getdynamodb()
	fmt.Println("emp ", emp)
	emp1, err := dynamodbattribute.MarshalMap(emp)
	fmt.Println("emp1 ", emp1)
	if err != nil {
		fmt.Println("Got error marshalling")
		fmt.Println(err.Error())
	} else {
		tableName := "emp"
		input := &dynamodb.PutItemInput{
			Item:      emp1,
			TableName: aws.String(tableName),
		}

		_, err = svc.PutItem(input)
		if err != nil {
			fmt.Println("Got error calling PutItem:")
		} else {
			fmt.Println("Successfully added ", emp)
			return
		}
	}

}

func list(w http.ResponseWriter) {
	svc := getdynamodb()
	params := &dynamodb.ScanInput{
		TableName: aws.String("emp"),
	}

	// Make the DynamoDB Query API call
	result, err := svc.Scan(params)
	if err != nil {
		fmt.Println("Query API call failed:")
		fmt.Println((err.Error()))
		os.Exit(1)
	}

	for _, i := range result.Items {
		e1 := EmpStruct{}
		err = dynamodbattribute.UnmarshalMap(i, &e1)
		if err != nil {
			fmt.Println("Got error unmarshalling:")
			fmt.Println(err.Error())
		} else {
			json.NewEncoder(w).Encode(e1)
		}
	}
}
