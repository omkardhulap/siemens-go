package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	
)

type EmpStruct struct {
	Empno  int     `json:"empno"`
	Ename  string  `json:"ename"`
	Salary float64 `json:"salary"`
}

func (e EmpStruct) string() string {
	return "empdetails"
}

func Emphandler(w http.ResponseWriter, req *http.Request) {
	switch req.Method {
	case "GET":
		//e := EmpStruct{"Empno": 10, "Ename": "aaa", "Salary": 111}
		e := EmpStruct{10, "aa", 111}
		fmt.Println(e)
		//list(w)
	case "POST":
		fmt.Fprintf(w, "Post from website! r.PostFrom = %v\n", req.PostForm)
		reqBody, _ := ioutil.ReadAll(req.Body)
		var emp EmpStruct
		json.Unmarshal(reqBody, &emp)
		fmt.Println(emp)
		Save(emp)
		json.NewEncoder(w).Encode(emp)
	}
}
