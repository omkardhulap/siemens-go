package main

import "fmt"

type Person struct {
	Name string
	Age  int
}

func (p Person) String() string {
	return fmt.Sprintf("my string() - %v (%v years) ", p.Name, p.Age)
}

func main() {
	a := Person{"Arthur Dent", 42}
	z := Person{"Beeblebrox", 9001}
	fmt.Println(a, z)
	fmt.Println("current ", a)
}
