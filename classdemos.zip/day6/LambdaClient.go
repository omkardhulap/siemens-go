package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/dynamodb"
	"github.com/aws/aws-sdk-go/service/dynamodb/dynamodbattribute"
)

func main(){
	sess, err := session.NewSession(&aws.Config{
		Region: aws.String("us-east-1")})

	if err != nil {
		fmt.Println("In err", err)
		panic("Problem in getting connection to AWS")
	} else {
		fmt.Println("Session Created Successfully")
		fmt.Println(sess)
		client := lambda.New(sess)
		payload, err := json.Marshal({
  "uname": "Check",
  "uage": 3333
})
	result, err := client.Invoke(
		&lambda.InvokeInput{FunctionName: aws.String("MyGoFunction1"),
		 Payload: payload})
	if err != nil {
		fmt.Println("Error calling MyGetItemsFunction")
	else{
	var resp getItemsResponse

err = json.Unmarshal(result.Payload, &resp)
if err != nil {
    fmt.Println("Error unmarshalling MyGetItemsFunction response")
    os.Exit(0)
}

    
}

	}
	
}
