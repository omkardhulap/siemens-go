package empmgr

type Emp struct {
	Empno  int
	Ename  string
	Salary float64
}
